"""
Utility scripts for SEO Intelligence system.

Contains:
- run_migration.py: Database migration runner
"""
